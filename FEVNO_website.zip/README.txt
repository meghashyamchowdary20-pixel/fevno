FEVNO WEBSITE — FREE VERSION

Files:
- index.html = complete website

HOW TO USE:
1. Open index.html in Chrome to preview it.
2. To publish for ₹0, create a free GitHub account at github.com.
3. Create a new public repository named: fevno
4. Upload index.html.
5. In Settings → Pages, choose Deploy from branch → main → /root.
6. GitHub will give you a free website address.

TO CUSTOMIZE:
- Product names/prices are inside index.html.
- Replace the placeholder product visuals with your own product photos later.
- Change Instagram link in the footer when you have your exact Instagram URL.

A custom domain such as fevno.com is normally not free; the website itself can be hosted free.
